import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 390;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // iphone1436TK (10:7)
        padding: EdgeInsets.fromLTRB(12*fem, 21*fem, 14*fem, 93*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
          image: DecorationImage (
            fit: BoxFit.cover,
            image: AssetImage (
              'assets/page-1/images/image-7-bg.png',
            ),
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              // image15buttonN9w (10:44)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 75*fem),
              width: 49*fem,
              height: 44*fem,
              child: Image.asset(
                'assets/page-1/images/image-15-button-HLD.png',
                fit: BoxFit.cover,
              ),
            ),
            Container(
              // autogroupi4gr5q3 (WKrn8djifPHaKji3YAi4gR)
              margin: EdgeInsets.fromLTRB(35*fem, 0*fem, 42*fem, 17*fem),
              width: double.infinity,
              height: 100*fem,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // autogroupapyboW9 (WKrnExtWEG3TR7YqhXAPyb)
                    margin: EdgeInsets.fromLTRB(0*fem, 26*fem, 0*fem, 9*fem),
                    height: double.infinity,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Text(
                          // becomfortedbytheu3P (10:26)
                          'Be comforted by the',
                          style: SafeGoogleFont (
                            'Carme',
                            fontSize: 20*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.2*ffem/fem,
                            color: Color(0xff000000),
                          ),
                        ),
                        Container(
                          // bibleELZ (10:23)
                          margin: EdgeInsets.fromLTRB(6*fem, 0*fem, 0*fem, 0*fem),
                          child: Text(
                            'BIBLE',
                            style: SafeGoogleFont (
                              'Modern Antiqua',
                              fontSize: 32*ffem,
                              fontWeight: FontWeight.w500,
                              height: 1.2575*ffem/fem,
                              color: Color(0xff000000),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // image12xXT (10:30)
                    width: 100*fem,
                    height: 100*fem,
                    child: Image.asset(
                      'assets/page-1/images/image-12-QYH.png',
                      fit: BoxFit.cover,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupnifbWJ5 (WKrnNxfBUK6zNkJAKkniFB)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 40*fem),
              padding: EdgeInsets.fromLTRB(41*fem, 9*fem, 58*fem, 10*fem),
              width: double.infinity,
              decoration: BoxDecoration (
                color: Color(0xfff2d282),
                borderRadius: BorderRadius.circular(30*fem),
                boxShadow: [
                  BoxShadow(
                    color: Color(0x3f000000),
                    offset: Offset(0*fem, 4*fem),
                    blurRadius: 2*fem,
                  ),
                ],
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // image14MZb (10:34)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 25*fem, 0*fem),
                    width: 100*fem,
                    height: 100*fem,
                    child: Image.asset(
                      'assets/page-1/images/image-14.png',
                      fit: BoxFit.cover,
                    ),
                  ),
                  Container(
                    // youarelovedyouarevaluedyouarew (10:35)
                    constraints: BoxConstraints (
                      maxWidth: 140*fem,
                    ),
                    child: Text(
                      'You are Loved\nYou are Valued\nYou are Worthy\nYou are Enough',
                      style: SafeGoogleFont (
                        'Inconsolata',
                        fontSize: 20*ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.05*ffem/fem,
                        color: Color(0xff000000),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupue8qMT7 (WKrnVd8kB2KbqmvGBHUe8q)
              margin: EdgeInsets.fromLTRB(8*fem, 0*fem, 10*fem, 26*fem),
              width: double.infinity,
              height: 64*fem,
              decoration: BoxDecoration (
                color: Color(0xff8fe4d5),
                borderRadius: BorderRadius.circular(30*fem),
                boxShadow: [
                  BoxShadow(
                    color: Color(0x3f000000),
                    offset: Offset(0*fem, 4*fem),
                    blurRadius: 2*fem,
                  ),
                ],
              ),
              child: Center(
                child: Text(
                  'Feeling Worried',
                  style: SafeGoogleFont (
                    'Inika',
                    fontSize: 25*ffem,
                    fontWeight: FontWeight.w700,
                    height: 1.3025*ffem/fem,
                    color: Color(0xccffffff),
                  ),
                ),
              ),
            ),
            Container(
              // autogroupkpcdkVF (WKrnaNVqMBPWfJoMoJKPcD)
              margin: EdgeInsets.fromLTRB(3*fem, 0*fem, 4*fem, 22*fem),
              width: double.infinity,
              height: 66*fem,
              decoration: BoxDecoration (
                color: Color(0xffe4ad8e),
                borderRadius: BorderRadius.circular(30*fem),
                boxShadow: [
                  BoxShadow(
                    color: Color(0x3f000000),
                    offset: Offset(0*fem, 4*fem),
                    blurRadius: 2*fem,
                  ),
                ],
              ),
              child: Center(
                child: Text(
                  'Feeling Anxious',
                  style: SafeGoogleFont (
                    'Inika',
                    fontSize: 25*ffem,
                    fontWeight: FontWeight.w700,
                    height: 1.3025*ffem/fem,
                    color: Color(0xffffffff),
                  ),
                ),
              ),
            ),
            Container(
              // autogroupwxyk1g5 (WKrnfcr6E69X3KMQxaWXyK)
              margin: EdgeInsets.fromLTRB(2*fem, 0*fem, 5*fem, 22*fem),
              width: double.infinity,
              height: 66*fem,
              decoration: BoxDecoration (
                color: Color(0xff7dee8f),
                borderRadius: BorderRadius.circular(30*fem),
                boxShadow: [
                  BoxShadow(
                    color: Color(0x3f000000),
                    offset: Offset(0*fem, 4*fem),
                    blurRadius: 2*fem,
                  ),
                ],
              ),
              child: Center(
                child: Text(
                  'Feeling Sad',
                  style: SafeGoogleFont (
                    'Inika',
                    fontSize: 25*ffem,
                    fontWeight: FontWeight.w700,
                    height: 1.3025*ffem/fem,
                    color: Color(0xffffffff),
                  ),
                ),
              ),
            ),
            Container(
              // autogroupzhhbEoj (WKrnjx4Cyx91tnWNxsZHhb)
              margin: EdgeInsets.fromLTRB(2*fem, 0*fem, 4*fem, 0*fem),
              width: double.infinity,
              height: 69*fem,
              decoration: BoxDecoration (
                color: Color(0xffe9eb89),
                borderRadius: BorderRadius.circular(30*fem),
                boxShadow: [
                  BoxShadow(
                    color: Color(0x3f000000),
                    offset: Offset(0*fem, 4*fem),
                    blurRadius: 2*fem,
                  ),
                ],
              ),
              child: Center(
                child: Text(
                  'Feeling Scared',
                  style: SafeGoogleFont (
                    'Inika',
                    fontSize: 25*ffem,
                    fontWeight: FontWeight.w700,
                    height: 1.3025*ffem/fem,
                    color: Color(0xffffffff),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}