import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 390;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // iphone142u3f (7:42)
        padding: EdgeInsets.fromLTRB(9*fem, 25*fem, 14*fem, 26*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
          image: DecorationImage (
            fit: BoxFit.cover,
            image: AssetImage (
              'assets/page-1/images/image-7-bg-mUM.png',
            ),
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              // image15buttonm5s (13:10)
              width: 49*fem,
              height: 44*fem,
              child: Image.asset(
                'assets/page-1/images/image-15-button.png',
                fit: BoxFit.cover,
              ),
            ),
            Container(
              // autogroupwhar5cM (WKriqp41Y5pe1u55YbwhAR)
              margin: EdgeInsets.fromLTRB(73*fem, 0*fem, 69*fem, 19*fem),
              width: double.infinity,
              height: 169*fem,
              child: Stack(
                children: [
                  Positioned(
                    // wateryourselfb4u (9:4)
                    left: 0*fem,
                    top: 130*fem,
                    child: Align(
                      child: SizedBox(
                        width: 225*fem,
                        height: 39*fem,
                        child: RichText(
                          text: TextSpan(
                            style: SafeGoogleFont (
                              'Inter',
                              fontSize: 32*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.2102272511*ffem/fem,
                              color: Color(0xff000000),
                            ),
                            children: [
                              TextSpan(
                                text: 'Water your sel',
                                style: SafeGoogleFont (
                                  'Irish Grover',
                                  fontSize: 32*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.21*ffem/fem,
                                  color: Color(0xff000000),
                                ),
                              ),
                              TextSpan(
                                text: 'f',
                                style: SafeGoogleFont (
                                  'Inter',
                                  fontSize: 32*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.2125*ffem/fem,
                                  color: Color(0xff000000),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // image8cnd (9:7)
                    left: 53*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 142*fem,
                        height: 138*fem,
                        child: Image.asset(
                          'assets/page-1/images/image-8.png',
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupn1b7wa1 (WKrizDyfCRxawbYXnZN1B7)
              margin: EdgeInsets.fromLTRB(3*fem, 0*fem, 0*fem, 15*fem),
              width: 364*fem,
              height: 119*fem,
              decoration: BoxDecoration (
                color: Color(0xff8ee4d5),
                borderRadius: BorderRadius.circular(30*fem),
                boxShadow: [
                  BoxShadow(
                    color: Color(0x3f000000),
                    offset: Offset(0*fem, 4*fem),
                    blurRadius: 2*fem,
                  ),
                ],
              ),
              child: Stack(
                children: [
                  Positioned(
                    // hatishappeningtomePwo (9:11)
                    left: 80*fem,
                    top: 31*fem,
                    child: Align(
                      child: SizedBox(
                        width: 165*fem,
                        height: 20*fem,
                        child: Text(
                          'hat is happening to me?',
                          style: SafeGoogleFont (
                            'Inika',
                            fontSize: 15*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.3025*ffem/fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // hyisthishappeningtomeGVo (9:13)
                    left: 75*fem,
                    top: 54*fem,
                    child: Align(
                      child: SizedBox(
                        width: 191*fem,
                        height: 20*fem,
                        child: Text(
                          'hy is this happening to me?',
                          style: SafeGoogleFont (
                            'Inika',
                            fontSize: 15*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.3025*ffem/fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // wx7j (9:12)
                    left: 11*fem,
                    top: 10*fem,
                    child: Align(
                      child: SizedBox(
                        width: 69*fem,
                        height: 84*fem,
                        child: Text(
                          'W',
                          style: SafeGoogleFont (
                            'Inika',
                            fontSize: 64*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.3025*ffem/fem,
                            color: Color(0xccffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // image939B (9:20)
                    left: 256*fem,
                    top: 4*fem,
                    child: Align(
                      child: SizedBox(
                        width: 100*fem,
                        height: 100*fem,
                        child: Image.asset(
                          'assets/page-1/images/image-9.png',
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupf5rskJV (WKrjC8oUn3wCndigoNF5Rs)
              margin: EdgeInsets.fromLTRB(3*fem, 0*fem, 0*fem, 14*fem),
              width: double.infinity,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // autogroupym3o5Lm (WKrjP8VAEd9K78VkfBym3o)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 24*fem, 2*fem),
                    padding: EdgeInsets.fromLTRB(15*fem, 28*fem, 15*fem, 9*fem),
                    width: 170*fem,
                    decoration: BoxDecoration (
                      color: Color(0xfff2d282),
                      borderRadius: BorderRadius.circular(30*fem),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x3f000000),
                          offset: Offset(0*fem, 4*fem),
                          blurRadius: 2*fem,
                        ),
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // becomfortedbytheKku (9:36)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 4*fem),
                          child: Text(
                            'Be comforted by the',
                            style: SafeGoogleFont (
                              'Carme',
                              fontSize: 15*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.2*ffem/fem,
                              color: Color(0xff000000),
                            ),
                          ),
                        ),
                        Container(
                          // bible34d (9:37)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 19*fem, 3*fem),
                          child: Text(
                            'BIBLE',
                            style: SafeGoogleFont (
                              'Modern Antiqua',
                              fontSize: 32*ffem,
                              fontWeight: FontWeight.w500,
                              height: 1.2575*ffem/fem,
                              color: Color(0xff000000),
                            ),
                          ),
                        ),
                        Container(
                          // image12wvh (9:33)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                          width: 100*fem,
                          height: 100*fem,
                          child: Image.asset(
                            'assets/page-1/images/image-12.png',
                            fit: BoxFit.cover,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupvssxfLu (WKrjWsmFdJMoHXQbWnvssX)
                    margin: EdgeInsets.fromLTRB(0*fem, 2*fem, 0*fem, 0*fem),
                    padding: EdgeInsets.fromLTRB(34*fem, 21*fem, 35*fem, 11*fem),
                    width: 170*fem,
                    decoration: BoxDecoration (
                      color: Color(0xff7dee8f),
                      borderRadius: BorderRadius.circular(30*fem),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x3f000000),
                          offset: Offset(0*fem, 4*fem),
                          blurRadius: 2*fem,
                        ),
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // relaxwithJuf (9:30)
                          margin: EdgeInsets.fromLTRB(4*fem, 0*fem, 0*fem, 0*fem),
                          child: Text(
                            'Relax with',
                            style: SafeGoogleFont (
                              'Carme',
                              fontSize: 15*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.2*ffem/fem,
                              color: Color(0xff000000),
                            ),
                          ),
                        ),
                        SizedBox(
                          height: 6*fem,
                        ),
                        Container(
                          // musicc9f (9:31)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 13*fem, 0*fem),
                          child: Text(
                            'MUSIC',
                            style: SafeGoogleFont (
                              'Modern Antiqua',
                              fontSize: 32*ffem,
                              fontWeight: FontWeight.w500,
                              height: 1.2575*ffem/fem,
                              color: Color(0xff000000),
                            ),
                          ),
                        ),
                        SizedBox(
                          height: 6*fem,
                        ),
                        Container(
                          // image11hgu (9:29)
                          margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 0*fem),
                          width: 100*fem,
                          height: 100*fem,
                          child: Image.asset(
                            'assets/page-1/images/image-11.png',
                            fit: BoxFit.cover,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroup9v57pmX (WKrjn7prZGwis5PoTN9v57)
              margin: EdgeInsets.fromLTRB(3*fem, 0*fem, 0*fem, 0*fem),
              width: double.infinity,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // autogroupyoehk9P (WKrjxXhB2dr42gZ5rNyoeh)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 24*fem, 5*fem),
                    padding: EdgeInsets.fromLTRB(20*fem, 15*fem, 18*fem, 8*fem),
                    width: 170*fem,
                    decoration: BoxDecoration (
                      color: Color(0xffe4ad8e),
                      borderRadius: BorderRadius.circular(30*fem),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x3f000000),
                          offset: Offset(0*fem, 4*fem),
                          blurRadius: 2*fem,
                        ),
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // enlightenyourmoodbywatchingedu (10:4)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 7*fem),
                          constraints: BoxConstraints (
                            maxWidth: 132*fem,
                          ),
                          child: Text(
                            'Enlighten your mood\nby watching educational ',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Carme',
                              fontSize: 12*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.2*ffem/fem,
                              color: Color(0xff000000),
                            ),
                          ),
                        ),
                        Container(
                          // videosgSM (10:5)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 18*fem, 3*fem),
                          child: Text(
                            'VIDEOS',
                            style: SafeGoogleFont (
                              'Modern Antiqua',
                              fontSize: 32*ffem,
                              fontWeight: FontWeight.w500,
                              height: 1.2575*ffem/fem,
                              color: Color(0xff000000),
                            ),
                          ),
                        ),
                        Container(
                          // image13bpD (10:3)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 4*fem, 0*fem),
                          width: 100*fem,
                          height: 100*fem,
                          child: Image.asset(
                            'assets/page-1/images/image-13.png',
                            fit: BoxFit.cover,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupl56rXC5 (WKrkB7AYsvk8d2HrFYL56R)
                    margin: EdgeInsets.fromLTRB(0*fem, 5*fem, 0*fem, 0*fem),
                    padding: EdgeInsets.fromLTRB(29*fem, 14*fem, 30*fem, 13*fem),
                    width: 170*fem,
                    decoration: BoxDecoration (
                      color: Color(0xffe9eb89),
                      borderRadius: BorderRadius.circular(30*fem),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x3f000000),
                          offset: Offset(0*fem, 4*fem),
                          blurRadius: 2*fem,
                        ),
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // talktomedicalprofessionalsCp1 (9:27)
                          margin: EdgeInsets.fromLTRB(6*fem, 0*fem, 0*fem, 2*fem),
                          constraints: BoxConstraints (
                            maxWidth: 105*fem,
                          ),
                          child: Text(
                            'Talk to Medical \nProfessionals',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Carme',
                              fontSize: 15*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.2*ffem/fem,
                              color: Color(0xff000000),
                            ),
                          ),
                        ),
                        Container(
                          // autogroupvd7w5so (WKrkFc34ChxzfKLU6vVd7w)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5*fem, 0*fem),
                          width: 106*fem,
                          height: 138*fem,
                          child: Stack(
                            children: [
                              Positioned(
                                // image10zjs (9:25)
                                left: 6*fem,
                                top: 38*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 100*fem,
                                    height: 100*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/image-10.png',
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // advice7Zb (9:26)
                                left: 0*fem,
                                top: 0*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 97*fem,
                                    height: 41*fem,
                                    child: Text(
                                      'ADVICE',
                                      style: SafeGoogleFont (
                                        'Modern Antiqua',
                                        fontSize: 32*ffem,
                                        fontWeight: FontWeight.w500,
                                        height: 1.2575*ffem/fem,
                                        color: Color(0xff000000),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}