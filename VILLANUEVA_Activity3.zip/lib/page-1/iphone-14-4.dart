import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 390;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // iphone144qYm (10:45)
        padding: EdgeInsets.fromLTRB(16*fem, 47*fem, 8*fem, 95*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          image: DecorationImage (
            fit: BoxFit.cover,
            image: AssetImage (
              'assets/page-1/images/image-7-bg-1iH.png',
            ),
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // autogroupgg89WQ1 (WKrm9APUrknYvsTvYjGg89)
              margin: EdgeInsets.fromLTRB(99*fem, 0*fem, 103*fem, 4*fem),
              padding: EdgeInsets.fromLTRB(43*fem, 15*fem, 72*fem, 15*fem),
              width: double.infinity,
              height: 145*fem,
              decoration: BoxDecoration (
                image: DecorationImage (
                  fit: BoxFit.cover,
                  image: AssetImage (
                    'assets/page-1/images/image-3-bg.png',
                  ),
                ),
              ),
              child: Align(
                // image4za5 (10:59)
                alignment: Alignment.topCenter,
                child: SizedBox(
                  width: 49*fem,
                  height: 45*fem,
                  child: Image.asset(
                    'assets/page-1/images/image-4.png',
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            ),
            Container(
              // growj1s (10:47)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 15*fem, 24*fem),
              width: 225*fem,
              height: 43*fem,
              child: Image.asset(
                'assets/page-1/images/grow-FzH.png',
                width: 225*fem,
                height: 43*fem,
              ),
            ),
            Container(
              // register3oF (10:61)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 28*fem),
              child: Text(
                'Register',
                style: SafeGoogleFont (
                  'Irish Grover',
                  fontSize: 32*ffem,
                  fontWeight: FontWeight.w400,
                  height: 1.21*ffem/fem,
                  color: Color(0xff000000),
                ),
              ),
            ),
            Container(
              // autogroupfpem9bP (WKrmEpti9xcyGwk7KjFpEM)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 21*fem),
              width: double.infinity,
              height: 47*fem,
              decoration: BoxDecoration (
                border: Border.all(color: Color(0xff000000)),
                color: Color(0xffcef1ce),
                borderRadius: BorderRadius.circular(50*fem),
                boxShadow: [
                  BoxShadow(
                    color: Color(0x3f000000),
                    offset: Offset(0*fem, 4*fem),
                    blurRadius: 2*fem,
                  ),
                ],
              ),
              child: Center(
                child: Text(
                  'Full name',
                  style: SafeGoogleFont (
                    'Inika',
                    fontSize: 25*ffem,
                    fontWeight: FontWeight.w700,
                    height: 1.3025*ffem/fem,
                    color: Color(0x1e000000),
                  ),
                ),
              ),
            ),
            Container(
              // autogroupbmehLQy (WKrmLzP79v9VBVhFdzbMEH)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 27*fem),
              width: double.infinity,
              height: 47*fem,
              decoration: BoxDecoration (
                border: Border.all(color: Color(0xff000000)),
                color: Color(0xffcef1ce),
                borderRadius: BorderRadius.circular(50*fem),
                boxShadow: [
                  BoxShadow(
                    color: Color(0x3f000000),
                    offset: Offset(0*fem, 4*fem),
                    blurRadius: 2*fem,
                  ),
                ],
              ),
              child: Center(
                child: Text(
                  'Age',
                  style: SafeGoogleFont (
                    'Inika',
                    fontSize: 25*ffem,
                    fontWeight: FontWeight.w700,
                    height: 1.3025*ffem/fem,
                    color: Color(0x1e000000),
                  ),
                ),
              ),
            ),
            Container(
              // autogroupytzuaaD (WKrmRuQatzSmBrU176Ytzu)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 23*fem),
              padding: EdgeInsets.fromLTRB(120*fem, 3*fem, 126*fem, 3*fem),
              width: double.infinity,
              height: 47*fem,
              decoration: BoxDecoration (
                border: Border.all(color: Color(0xff000000)),
                color: Color(0xffcef1ce),
                borderRadius: BorderRadius.circular(50*fem),
                boxShadow: [
                  BoxShadow(
                    color: Color(0x3f000000),
                    offset: Offset(0*fem, 4*fem),
                    blurRadius: 2*fem,
                  ),
                ],
              ),
              child: Text(
                'Username',
                style: SafeGoogleFont (
                  'Inika',
                  fontSize: 25*ffem,
                  fontWeight: FontWeight.w700,
                  height: 1.3025*ffem/fem,
                  color: Color(0x1e000000),
                ),
              ),
            ),
            Container(
              // autogroupa3socWu (WKrmWKStwK3wdjZo2wA3so)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 27*fem),
              width: double.infinity,
              height: 47*fem,
              decoration: BoxDecoration (
                border: Border.all(color: Color(0xff000000)),
                color: Color(0xffcef1ce),
                borderRadius: BorderRadius.circular(50*fem),
                boxShadow: [
                  BoxShadow(
                    color: Color(0x3f000000),
                    offset: Offset(0*fem, 4*fem),
                    blurRadius: 2*fem,
                  ),
                ],
              ),
              child: Center(
                child: Text(
                  'Password',
                  style: SafeGoogleFont (
                    'Inika',
                    fontSize: 25*ffem,
                    fontWeight: FontWeight.w700,
                    height: 1.3025*ffem/fem,
                    color: Color(0x1e000000),
                  ),
                ),
              ),
            ),
            Container(
              // autogroupcoc559b (WKrmaef1hB3SVCim3ECoc5)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 43*fem),
              padding: EdgeInsets.fromLTRB(85*fem, 1*fem, 65*fem, 1*fem),
              width: double.infinity,
              height: 47*fem,
              decoration: BoxDecoration (
                border: Border.all(color: Color(0xff000000)),
                color: Color(0xffcef1ce),
                borderRadius: BorderRadius.circular(50*fem),
                boxShadow: [
                  BoxShadow(
                    color: Color(0x3f000000),
                    offset: Offset(0*fem, 4*fem),
                    blurRadius: 2*fem,
                  ),
                ],
              ),
              child: Text(
                'Re-enter Password',
                textAlign: TextAlign.center,
                style: SafeGoogleFont (
                  'Inika',
                  fontSize: 25*ffem,
                  fontWeight: FontWeight.w700,
                  height: 1.3025*ffem/fem,
                  color: Color(0x1e000000),
                ),
              ),
            ),
            Container(
              // autogroupamtv4XK (WKrmejNYbfBtZS3FGtaMtV)
              margin: EdgeInsets.fromLTRB(32*fem, 0*fem, 32*fem, 0*fem),
              width: double.infinity,
              height: 43*fem,
              decoration: BoxDecoration (
                color: Color(0xff8fe49c),
                borderRadius: BorderRadius.circular(60*fem),
                boxShadow: [
                  BoxShadow(
                    color: Color(0x3f000000),
                    offset: Offset(0*fem, 4*fem),
                    blurRadius: 2*fem,
                  ),
                ],
              ),
              child: Center(
                child: Text(
                  'CREATE',
                  style: SafeGoogleFont (
                    'Inika',
                    fontSize: 20*ffem,
                    fontWeight: FontWeight.w700,
                    height: 1.3025*ffem/fem,
                    color: Color(0xff000000),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}