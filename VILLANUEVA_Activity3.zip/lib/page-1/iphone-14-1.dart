import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 390;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // iphone1417zR (1:3)
        padding: EdgeInsets.fromLTRB(0*fem, 123*fem, 0*fem, 88*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          image: DecorationImage (
            fit: BoxFit.cover,
            image: AssetImage (
              'assets/page-1/images/image-7-bg-G7T.png',
            ),
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // autogroupzv8ug3s (WKrhZGMtZPCfzQ3aJczV8u)
              margin: EdgeInsets.fromLTRB(89*fem, 0*fem, 75*fem, 25*fem),
              width: double.infinity,
              height: 237*fem,
              child: Stack(
                children: [
                  Positioned(
                    // growyYm (5:23)
                    left: 0*fem,
                    top: 194*fem,
                    child: Align(
                      child: SizedBox(
                        width: 225*fem,
                        height: 43*fem,
                        child: Image.asset(
                          'assets/page-1/images/grow.png',
                          width: 225*fem,
                          height: 43*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // image3TTw (5:20)
                    left: 21*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 205*fem,
                        height: 207*fem,
                        child: Image.asset(
                          'assets/page-1/images/image-3.png',
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // image4ANM (5:22)
                    left: 75*fem,
                    top: 58*fem,
                    child: Align(
                      child: SizedBox(
                        width: 49*fem,
                        height: 45*fem,
                        child: Image.asset(
                          'assets/page-1/images/image-4-iAu.png',
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // welcomeGwB (6:29)
              margin: EdgeInsets.fromLTRB(23*fem, 0*fem, 0*fem, 24*fem),
              child: Text(
                'Welcome',
                style: SafeGoogleFont (
                  'Inika',
                  fontSize: 25*ffem,
                  fontWeight: FontWeight.w700,
                  height: 1.3025*ffem/fem,
                  color: Color(0xffffffff),
                ),
              ),
            ),
            Container(
              // autogroupwb1j9k5 (WKrhjqtbbfLNLq6WYiwB1j)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 122*fem, 34*fem),
              padding: EdgeInsets.fromLTRB(65*fem, 8*fem, 44*fem, 16*fem),
              width: double.infinity,
              decoration: BoxDecoration (
                border: Border.all(color: Color(0xff000000)),
                color: Color(0xffcef1ce),
                borderRadius: BorderRadius.circular(50*fem),
                boxShadow: [
                  BoxShadow(
                    color: Color(0x3f000000),
                    offset: Offset(0*fem, 4*fem),
                    blurRadius: 2*fem,
                  ),
                ],
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // image1Bwf (5:12)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 35*fem, 0*fem),
                    width: 42*fem,
                    height: 41*fem,
                    child: Image.asset(
                      'assets/page-1/images/image-1.png',
                      fit: BoxFit.cover,
                    ),
                  ),
                  Container(
                    // username633 (5:9)
                    margin: EdgeInsets.fromLTRB(0*fem, 8*fem, 0*fem, 0*fem),
                    child: Text(
                      'Username',
                      style: SafeGoogleFont (
                        'Inika',
                        fontSize: 25*ffem,
                        fontWeight: FontWeight.w700,
                        height: 1.3025*ffem/fem,
                        color: Color(0x1e000000),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupb577Pnq (WKrhuRSyES5saJoXiJB577)
              margin: EdgeInsets.fromLTRB(119*fem, 0*fem, 0*fem, 76*fem),
              padding: EdgeInsets.fromLTRB(42*fem, 8*fem, 67*fem, 8*fem),
              width: double.infinity,
              height: 67*fem,
              decoration: BoxDecoration (
                border: Border.all(color: Color(0xff000000)),
                color: Color(0xffcff1ce),
                borderRadius: BorderRadius.circular(50*fem),
                boxShadow: [
                  BoxShadow(
                    color: Color(0x3f000000),
                    offset: Offset(0*fem, 4*fem),
                    blurRadius: 2*fem,
                  ),
                ],
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // passwordFa9 (5:10)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 44*fem, 4*fem),
                    child: Text(
                      'Password',
                      style: SafeGoogleFont (
                        'Inika',
                        fontSize: 25*ffem,
                        fontWeight: FontWeight.w700,
                        height: 1.3025*ffem/fem,
                        color: Color(0x1e000000),
                      ),
                    ),
                  ),
                  Container(
                    // image2Zqj (5:14)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 11*fem),
                    width: 42*fem,
                    height: 40*fem,
                    child: Image.asset(
                      'assets/page-1/images/image-2.png',
                      fit: BoxFit.cover,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogrouprzzmJHX (WKri25vXw9JV3LRdZprzzm)
              margin: EdgeInsets.fromLTRB(48*fem, 0*fem, 40*fem, 9*fem),
              width: double.infinity,
              height: 43*fem,
              decoration: BoxDecoration (
                color: Color(0xff8fe49c),
                borderRadius: BorderRadius.circular(60*fem),
                boxShadow: [
                  BoxShadow(
                    color: Color(0x3f000000),
                    offset: Offset(0*fem, 4*fem),
                    blurRadius: 2*fem,
                  ),
                ],
              ),
              child: Center(
                child: Text(
                  'LOGIN',
                  style: SafeGoogleFont (
                    'Inika',
                    fontSize: 20*ffem,
                    fontWeight: FontWeight.w700,
                    height: 1.3025*ffem/fem,
                    color: Color(0xff000000),
                  ),
                ),
              ),
            ),
            Container(
              // autogroupg9cmic9 (WKri6v7pPkz5THFZ7PG9cm)
              margin: EdgeInsets.fromLTRB(63*fem, 0*fem, 63*fem, 0*fem),
              width: double.infinity,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // donthaveaccountyetrCZ (6:33)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 7*fem, 0*fem),
                    child: Text(
                      'Dont have account yet? ',
                      style: SafeGoogleFont (
                        'Inika',
                        fontSize: 15*ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.3025*ffem/fem,
                        color: Color(0x4c000000),
                      ),
                    ),
                  ),
                  Text(
                    // signupherebuttonADF (9:10)
                    'Sign  up here',
                    style: SafeGoogleFont (
                      'Inika',
                      fontSize: 15*ffem,
                      fontWeight: FontWeight.w700,
                      height: 1.3025*ffem/fem,
                      decoration: TextDecoration.underline,
                      color: Color(0x99000000),
                      decorationColor: Color(0x99000000),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}